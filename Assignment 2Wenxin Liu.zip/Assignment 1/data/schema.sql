

CREATE DATABASE IF NOT EXISTS shopping_cart_db;
USE shopping_cart_db;


CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(50) DEFAULT '📦',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    stock INT NOT NULL DEFAULT 0 CHECK (stock >= 0),
    image_url VARCHAR(500) DEFAULT NULL,
    category_id INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
    INDEX idx_category (category_id),
    INDEX idx_active (is_active),
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL DEFAULT 0,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_cart_product (user_id, product_id),
    INDEX idx_product (product_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL DEFAULT 0,
    total_amount DECIMAL(10, 2) NOT NULL CHECK (total_amount >= 0),
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(255) DEFAULT NULL,
    shipping_address TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_created (created_at),
    INDEX idx_user_orders (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    price_at_purchase DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
    INDEX idx_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO categories (name, description, icon) VALUES
('Electronics', 'Smartphones, laptops, tablets, and accessories', '📱'),
('Clothing', 'Fashion items including shirts, pants, and shoes', '👕'),
('Books', 'Physical and digital books across all genres', '📚'),
('Home & Garden', 'Furniture, decor, and gardening supplies', '🏠'),
('Sports', 'Athletic equipment and outdoor gear', '⚽');

INSERT INTO products (name, description, price, stock, image_url, category_id) VALUES
-- Electronics
('iPhone 15 Pro', 'Latest Apple smartphone with A17 Pro chip, titanium design', 999.99, 50, 'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?w=400&h=400&fit=crop', 1),
('Samsung Galaxy S24', 'Android flagship with AI features and stunning display', 849.99, 45, 'https://images.unsplash.com/photo-1610945265064-0e34e5519b7f?w=400&h=400&fit=crop', 1),
('MacBook Air M3', 'Thin and light laptop with Apple M3 chip', 1099.99, 30, 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=400&fit=crop', 1),
('Sony WH-1000XM5', 'Premium noise-cancelling wireless headphones', 349.99, 60, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop', 1),
('iPad Pro 12.9"', 'Powerful tablet with M2 chip and Liquid Retina XDR', 1099.99, 35, 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=400&fit=crop', 1),

-- Clothing
('Classic Denim Jacket', 'Timeless denim jacket with modern fit', 89.99, 100, 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop', 2),
('Cotton T-Shirt Pack', 'Pack of 3 premium cotton t-shirts in various colors', 39.99, 200, 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop', 2),
('Running Shoes Pro', 'Lightweight running shoes with responsive cushioning', 129.99, 75, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop', 2),
('Winter Parka Coat', 'Warm and waterproof winter coat', 199.99, 40, 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=400&h=400&fit=crop', 2),

-- Books
('The Art of Programming', 'Comprehensive guide to software development practices', 49.99, 150, 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400&h=400&fit=crop', 3),
('Web Development Mastery', 'Full-stack web development from basics to advanced', 59.99, 120, 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=400&fit=crop', 3),
('Database Design Patterns', 'Best practices for scalable database architecture', 44.99, 80, 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=400&h=400&fit=crop', 3),

-- Home & Garden
('Smart LED Desk Lamp', 'Adjustable LED lamp with multiple brightness levels', 49.99, 90, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400&h=400&fit=crop', 4),
('Indoor Plant Set', 'Set of 3 low-maintenance indoor plants with pots', 34.99, 60, 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400&h=400&fit=crop', 4),
('Ergonomic Office Chair', 'Comfortable chair with lumbar support', 299.99, 25, 'https://images.unsplash.com/photo-1580480055273-228ff5388ef8?w=400&h=400&fit=crop', 4),

-- Sports
('Professional Soccer Ball', 'FIFA-approved match ball', 79.99, 100, 'https://images.unsplash.com/photo-1614632537197-38a17061c2bd?w=400&h=400&fit=crop', 5),
('Yoga Mat Premium', 'Non-slip yoga mat with carrying strap', 29.99, 150, 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400&h=400&fit=crop', 5),
('Fitness Tracker Watch', 'Smart watch with heart rate and GPS tracking', 149.99, 55, 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=400&h=400&fit=crop', 5);

DELIMITER //
CREATE PROCEDURE IF NOT EXISTS clear_cart()
BEGIN
    DELETE FROM cart_items;
END //
DELIMITER ;

CREATE OR REPLACE VIEW cart_view AS
SELECT 
    ci.user_id,
    ci.id AS cart_item_id,
    ci.quantity,
    ci.added_at,
    p.id AS product_id,
    p.name AS product_name,
    p.description,
    p.price,
    p.image_url,
    p.stock,
    c.name AS category_name,
    (p.price * ci.quantity) AS subtotal
FROM cart_items ci
INNER JOIN products p ON ci.product_id = p.id
INNER JOIN categories c ON p.category_id = c.id
WHERE p.is_active = TRUE;

CREATE OR REPLACE VIEW cart_summary AS
SELECT
    ci.user_id,
    COUNT(*) AS total_items,
    COALESCE(SUM(p.price * ci.quantity), 0) AS total_amount,
    COALESCE(SUM(ci.quantity), 0) AS total_quantity
FROM cart_items ci
INNER JOIN products p ON ci.product_id = p.id
WHERE p.is_active = TRUE
GROUP BY ci.user_id;

INSERT IGNORE INTO users (username, email, password_hash, role)
VALUES ('admin', 'admin@maison.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
