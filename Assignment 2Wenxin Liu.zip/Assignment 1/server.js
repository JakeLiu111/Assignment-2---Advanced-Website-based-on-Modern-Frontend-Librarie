const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 3101;
const JWT_SECRET = process.env.JWT_SECRET || 'maison-secret-key-2024';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '123456',
    database: 'shopping_cart_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    charset: 'utf8mb4',
    decimalNumbers: true
};

let pool;

async function initializeDatabase() {
    try {
        const connection = await mysql.createConnection({
            host: dbConfig.host,
            user: dbConfig.user,
            password: dbConfig.password,
            multipleStatements: true
        });

        await connection.query(`
            CREATE DATABASE IF NOT EXISTS ${dbConfig.database};
            USE ${dbConfig.database};

            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) NOT NULL UNIQUE,
                email VARCHAR(255) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                role ENUM('user', 'admin') DEFAULT 'user',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_username (username),
                INDEX idx_email (email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

            CREATE TABLE IF NOT EXISTS categories (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL UNIQUE,
                description TEXT,
                icon VARCHAR(50) DEFAULT '📦',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

            CREATE TABLE IF NOT EXISTS products (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(200) NOT NULL,
                description TEXT,
                price DECIMAL(10, 2) NOT NULL,
                stock INT NOT NULL DEFAULT 0,
                image_url VARCHAR(500) DEFAULT NULL,
                category_id INT NOT NULL,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

            CREATE TABLE IF NOT EXISTS cart_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL DEFAULT 0,
                product_id INT NOT NULL,
                quantity INT NOT NULL DEFAULT 1,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
                UNIQUE KEY unique_user_cart_product (user_id, product_id),
                INDEX idx_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

            CREATE TABLE IF NOT EXISTS orders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL DEFAULT 0,
                total_amount DECIMAL(10, 2) NOT NULL,
                status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
                customer_name VARCHAR(100) NOT NULL,
                customer_email VARCHAR(255) DEFAULT NULL,
                shipping_address TEXT,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_status (status),
                INDEX idx_created (created_at),
                INDEX idx_user_orders (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

            CREATE TABLE IF NOT EXISTS order_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                order_id INT NOT NULL,
                product_id INT NOT NULL,
                product_name VARCHAR(200) NOT NULL,
                price_at_purchase DECIMAL(10, 2) NOT NULL,
                quantity INT NOT NULL,
                subtotal DECIMAL(10, 2) NOT NULL,
                FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

            INSERT IGNORE INTO users (username, email, password_hash, role)
            VALUES ('admin', 'admin@admin.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
        `);

        const [categories] = await connection.query(`SELECT COUNT(*) as count FROM ${dbConfig.database}.categories`);
        if (categories[0].count === 0) {
            await connection.query(`
                USE ${dbConfig.database};
                INSERT INTO categories (name, description, icon) VALUES
                ('Electronics', 'Smartphones, laptops, tablets, and accessories', '📱'),
                ('Clothing', 'Fashion items including shirts, pants, and shoes', '👕'),
                ('Books', 'Physical and digital books across all genres', '📚'),
                ('Home & Garden', 'Furniture, decor, and gardening supplies', '🏠'),
                ('Sports', 'Athletic equipment and outdoor gear', '⚽');

                INSERT INTO products (name, description, price, stock, image_url, category_id) VALUES
                ('iPhone 15 Pro', 'Latest Apple smartphone with A17 Pro chip, titanium design', 999.99, 50, 'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?w=400&h=400&fit=crop', 1),
                ('Samsung Galaxy S24', 'Android flagship with AI features and stunning display', 849.99, 45, 'https://images.unsplash.com/photo-1610945265064-0e34e5519b7f?w=400&h=400&fit=crop', 1),
                ('MacBook Air M3', 'Thin and light laptop with Apple M3 chip', 1099.99, 30, 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=400&fit=crop', 1),
                ('Sony WH-1000XM5', 'Premium noise-cancelling wireless headphones', 349.99, 60, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop', 1),
                ('iPad Pro 12.9"', 'Powerful tablet with M2 chip and Liquid Retina XDR', 1099.99, 35, 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=400&fit=crop', 1),
                ('Classic Denim Jacket', 'Timeless denim jacket with modern fit', 89.99, 100, 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop', 2),
                ('Cotton T-Shirt Pack', 'Pack of 3 premium cotton t-shirts in various colors', 39.99, 200, 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop', 2),
                ('Running Shoes Pro', 'Lightweight running shoes with responsive cushioning', 129.99, 75, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop', 2),
                ('Winter Parka Coat', 'Warm and waterproof winter coat', 199.99, 40, 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=400&h=400&fit=crop', 2),
                ('The Art of Programming', 'Comprehensive guide to software development practices', 49.99, 150, 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400&h=400&fit=crop', 3),
                ('Web Development Mastery', 'Full-stack web development from basics to advanced', 59.99, 120, 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=400&fit=crop', 3),
                ('Database Design Patterns', 'Best practices for scalable database architecture', 44.99, 80, 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=400&h=400&fit=crop', 3),
                ('Smart LED Desk Lamp', 'Adjustable LED lamp with multiple brightness levels', 49.99, 90, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400&h=400&fit=crop', 4),
                ('Indoor Plant Set', 'Set of 3 low-maintenance indoor plants with pots', 34.99, 60, 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400&h=400&fit=crop', 4),
                ('Ergonomic Office Chair', 'Comfortable chair with lumbar support', 299.99, 25, 'https://images.unsplash.com/photo-1580480055273-228ff5388ef8?w=400&h=400&fit=crop', 4),
                ('Professional Soccer Ball', 'FIFA-approved match ball', 79.99, 100, 'https://images.unsplash.com/photo-1614632537197-38a17061c2bd?w=400&h=400&fit=crop', 5),
                ('Yoga Mat Premium', 'Non-slip yoga mat with carrying strap', 29.99, 150, 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400&h=400&fit=crop', 5),
                ('Fitness Tracker Watch', 'Smart watch with heart rate and GPS tracking', 149.99, 55, 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=400&h=400&fit=crop', 5);

                INSERT INTO cart_items (product_id, quantity) VALUES (1, 1), (7, 2), (13, 1);
            `);
        }

        await connection.end();
        pool = mysql.createPool(dbConfig);
        console.log('Database initialized successfully');
    } catch (error) {
        console.error('Database initialization error:', error.message);
        console.log('Server will continue but database operations may fail');
        pool = mysql.createPool(dbConfig);
    }
}

initializeDatabase();

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const errorHandler = (err, req, res, next) => {
    console.error('Server Error:', err.message);
    res.status(err.status || 500).json({
        success: false,
        message: err.message || 'Internal server error',
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
};

const authMiddleware = asyncHandler(async (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        const err = new Error('Authentication required');
        err.status = 401;
        throw err;
    }
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const [users] = await pool.query('SELECT id, username, email, role FROM users WHERE id = ?', [decoded.id]);
        if (users.length === 0) {
            const err = new Error('User not found');
            err.status = 401;
            throw err;
        }
        req.user = users[0];
        next();
    } catch (err) {
        if (err.status) throw err;
        const e = new Error('Invalid or expired token');
        e.status = 401;
        throw e;
    }
});

const adminMiddleware = asyncHandler(async (req, res, next) => {
    if (!req.user || req.user.role !== 'admin') {
        const err = new Error('Admin access required');
        err.status = 403;
        throw err;
    }
    next();
});

app.post('/api/auth/register', asyncHandler(async (req, res) => {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
        const err = new Error('Username, email, and password are required');
        err.status = 400;
        throw err;
    }
    if (username.length < 3 || username.length > 50) {
        const err = new Error('Username must be 3-50 characters');
        err.status = 400;
        throw err;
    }
    if (password.length < 6) {
        const err = new Error('Password must be at least 6 characters');
        err.status = 400;
        throw err;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        const err = new Error('Invalid email format');
        err.status = 400;
        throw err;
    }
    const [existing] = await pool.query(
        'SELECT id FROM users WHERE username = ? OR email = ?',
        [username, email]
    );
    if (existing.length > 0) {
        const err = new Error('Username or email already exists');
        err.status = 409;
        throw err;
    }
    const password_hash = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
        'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
        [username, email, password_hash]
    );
    const token = jwt.sign({ id: result.insertId, role: 'user' }, JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({
        success: true,
        data: { id: result.insertId, username, email, role: 'user' },
        token,
        message: 'Registration successful'
    });
}));

app.post('/api/auth/login', asyncHandler(async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        const err = new Error('Email and password are required');
        err.status = 400;
        throw err;
    }
    const [users] = await pool.query(
        'SELECT id, username, email, password_hash, role FROM users WHERE email = ?',
        [email]
    );
    if (users.length === 0) {
        const err = new Error('Invalid email or password');
        err.status = 401;
        throw err;
    }
    const user = users[0];
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
        const err = new Error('Invalid email or password');
        err.status = 401;
        throw err;
    }
    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    res.json({
        success: true,
        data: { id: user.id, username: user.username, email: user.email, role: user.role },
        token,
        message: 'Login successful'
    });
}));

app.get('/api/auth/me', authMiddleware, asyncHandler(async (req, res) => {
    res.json({ success: true, data: req.user });
}));

app.get('/api/admin/carts', authMiddleware, adminMiddleware, asyncHandler(async (req, res) => {
    const [rows] = await pool.query(`
        SELECT
            u.id AS user_id,
            u.username,
            u.email,
            u.role,
            u.created_at AS user_created_at,
            ci.id AS cart_item_id,
            ci.quantity,
            ci.added_at,
            p.id AS product_id,
            p.name AS product_name,
            p.price,
            p.image_url,
            p.stock,
            c.name AS category_name,
            (p.price * ci.quantity) AS subtotal
        FROM users u
        LEFT JOIN cart_items ci ON ci.user_id = u.id
        LEFT JOIN products p ON ci.product_id = p.id AND p.is_active = TRUE
        LEFT JOIN categories c ON p.category_id = c.id
        ORDER BY u.id, ci.added_at DESC
    `);

    const userMap = {};
    rows.forEach(row => {
        if (!userMap[row.user_id]) {
            userMap[row.user_id] = {
                id: row.user_id,
                username: row.username,
                email: row.email,
                role: row.role,
                created_at: row.user_created_at,
                cart: [],
                cart_summary: { total_items: 0, total_amount: 0, total_quantity: 0 }
            };
        }
        if (row.cart_item_id !== null) {
            userMap[row.user_id].cart.push({
                cart_item_id: row.cart_item_id,
                quantity: row.quantity,
                added_at: row.added_at,
                product_id: row.product_id,
                product_name: row.product_name,
                price: row.price,
                image_url: row.image_url,
                stock: row.stock,
                category_name: row.category_name,
                subtotal: row.subtotal
            });
            userMap[row.user_id].cart_summary.total_items += 1;
            userMap[row.user_id].cart_summary.total_quantity += row.quantity;
            userMap[row.user_id].cart_summary.total_amount += parseFloat(row.subtotal);
        }
    });

    const users = Object.values(userMap).sort((a, b) => b.id - a.id);
    res.json({ success: true, data: users });
}));

app.get('/api/categories', asyncHandler(async (req, res) => {
    const [rows] = await pool.query('SELECT * FROM categories ORDER BY name');
    res.json({ success: true, data: rows });
}));

app.get('/api/products', asyncHandler(async (req, res) => {
    const { category, search, sort } = req.query;
    let query = `
        SELECT p.*, c.name AS category_name, c.icon AS category_icon
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.is_active = TRUE
    `;
    const params = [];

    if (category && category !== 'all') {
        query += ' AND p.category_id = ?';
        params.push(category);
    }

    if (search) {
        query += ' AND (p.name LIKE ? OR p.description LIKE ?)';
        params.push(`%${search}%`, `%${search}%`);
    }

    const validSorts = ['name', 'price', 'created_at'];
    const sortField = validSorts.includes(sort) ? sort : 'p.id';
    const sortOrder = req.query.order === 'desc' ? 'DESC' : 'ASC';
    query += ` ORDER BY ${sortField} ${sortOrder}`;

    const [rows] = await pool.query(query, params);
    res.json({ success: true, data: rows });
}));

app.get('/api/products/:id', asyncHandler(async (req, res) => {
    const [rows] = await pool.query(`
        SELECT p.*, c.name AS category_name, c.icon AS category_icon
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.id = ? AND p.is_active = TRUE
    `, [req.params.id]);

    if (rows.length === 0) {
        const error = new Error('Product not found');
        error.status = 404;
        throw error;
    }
    res.json({ success: true, data: rows[0] });
}));

app.post('/api/products', asyncHandler(async (req, res) => {
    const { name, description, price, stock, image_url, category_id } = req.body;

    if (!name || price === undefined || !category_id) {
        const error = new Error('Name, price, and category are required');
        error.status = 400;
        throw error;
    }

    const [result] = await pool.query(
        'INSERT INTO products (name, description, price, stock, image_url, category_id) VALUES (?, ?, ?, ?, ?, ?)',
        [name, description || '', price, stock || 0, image_url || null, category_id]
    );

    const [newProduct] = await pool.query(`
        SELECT p.*, c.name AS category_name, c.icon AS category_icon
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.id = ?
    `, [result.insertId]);

    res.status(201).json({ success: true, data: newProduct[0], message: 'Product created successfully' });
}));

app.put('/api/products/:id', asyncHandler(async (req, res) => {
    const { name, description, price, stock, image_url, category_id, is_active } = req.body;

    const [existing] = await pool.query('SELECT id FROM products WHERE id = ?', [req.params.id]);
    if (existing.length === 0) {
        const error = new Error('Product not found');
        error.status = 404;
        throw error;
    }

    const updates = [];
    const params = [];

    if (name !== undefined) { updates.push('name = ?'); params.push(name); }
    if (description !== undefined) { updates.push('description = ?'); params.push(description); }
    if (price !== undefined) { updates.push('price = ?'); params.push(price); }
    if (stock !== undefined) { updates.push('stock = ?'); params.push(stock); }
    if (image_url !== undefined) { updates.push('image_url = ?'); params.push(image_url); }
    if (category_id !== undefined) { updates.push('category_id = ?'); params.push(category_id); }
    if (is_active !== undefined) { updates.push('is_active = ?'); params.push(is_active); }

    if (updates.length === 0) {
        const error = new Error('No fields to update');
        error.status = 400;
        throw error;
    }

    params.push(req.params.id);
    await pool.query(`UPDATE products SET ${updates.join(', ')} WHERE id = ?`, params);

    const [updated] = await pool.query(`
        SELECT p.*, c.name AS category_name, c.icon AS category_icon
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.id = ?
    `, [req.params.id]);

    res.json({ success: true, data: updated[0], message: 'Product updated successfully' });
}));

app.delete('/api/products/:id', asyncHandler(async (req, res) => {
    const [existing] = await pool.query('SELECT id FROM products WHERE id = ?', [req.params.id]);
    if (existing.length === 0) {
        const error = new Error('Product not found');
        error.status = 404;
        throw error;
    }

    await pool.query('UPDATE products SET is_active = FALSE WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Product deleted successfully' });
}));

app.get('/api/cart', authMiddleware, asyncHandler(async (req, res) => {
    const [rows] = await pool.query(`
        SELECT
            ci.id AS cart_item_id,
            ci.quantity,
            ci.added_at,
            p.id AS product_id,
            p.name AS product_name,
            p.description,
            p.price,
            p.image_url,
            p.stock,
            c.name AS category_name,
            (p.price * ci.quantity) AS subtotal
        FROM cart_items ci
        INNER JOIN products p ON ci.product_id = p.id
        INNER JOIN categories c ON p.category_id = c.id
        WHERE ci.user_id = ? AND p.is_active = TRUE
        ORDER BY ci.added_at DESC
    `, [req.user.id]);

    const [summary] = await pool.query(`
        SELECT
            COUNT(*) AS total_items,
            COALESCE(SUM(p.price * ci.quantity), 0) AS total_amount,
            COALESCE(SUM(ci.quantity), 0) AS total_quantity
        FROM cart_items ci
        INNER JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ? AND p.is_active = TRUE
    `, [req.user.id]);

    res.json({ success: true, data: rows, summary: summary[0] });
}));

app.post('/api/cart', authMiddleware, asyncHandler(async (req, res) => {
    const { product_id, quantity = 1 } = req.body;

    if (!product_id) {
        const error = new Error('Product ID is required');
        error.status = 400;
        throw error;
    }

    if (quantity < 1) {
        const error = new Error('Quantity must be at least 1');
        error.status = 400;
        throw error;
    }

    const [product] = await pool.query(
        'SELECT id, stock, is_active FROM products WHERE id = ?',
        [product_id]
    );

    if (product.length === 0 || !product[0].is_active) {
        const error = new Error('Product not found or unavailable');
        error.status = 404;
        throw error;
    }

    if (product[0].stock < quantity) {
        const error = new Error('Insufficient stock available');
        error.status = 400;
        throw error;
    }

    const [existing] = await pool.query(
        'SELECT id, quantity FROM cart_items WHERE user_id = ? AND product_id = ?',
        [req.user.id, product_id]
    );

    if (existing.length > 0) {
        const newQuantity = existing[0].quantity + quantity;
        if (newQuantity > product[0].stock) {
            const error = new Error(`Cannot add more. Only ${product[0].stock} available in stock`);
            error.status = 400;
            throw error;
        }
        await pool.query(
            'UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?',
            [newQuantity, req.user.id, product_id]
        );
    } else {
        await pool.query(
            'INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)',
            [req.user.id, product_id, quantity]
        );
    }

    const [cartItem] = await pool.query(`
        SELECT
            ci.id AS cart_item_id,
            ci.quantity,
            p.id AS product_id,
            p.name AS product_name,
            p.price,
            p.image_url,
            (p.price * ci.quantity) AS subtotal
        FROM cart_items ci
        INNER JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ? AND ci.product_id = ?
    `, [req.user.id, product_id]);

    res.status(201).json({ success: true, data: cartItem[0], message: 'Added to cart' });
}));

app.put('/api/cart/:productId', authMiddleware, asyncHandler(async (req, res) => {
    const { quantity } = req.body;

    if (quantity === undefined || quantity < 1) {
        const error = new Error('Valid quantity is required');
        error.status = 400;
        throw error;
    }

    const [cartItem] = await pool.query(`
        SELECT ci.id, ci.quantity, p.stock, p.is_active
        FROM cart_items ci
        INNER JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ? AND ci.product_id = ? AND p.is_active = TRUE
    `, [req.user.id, req.params.productId]);

    if (cartItem.length === 0) {
        const error = new Error('Cart item not found');
        error.status = 404;
        throw error;
    }

    if (quantity > cartItem[0].stock) {
        const error = new Error(`Cannot set quantity to ${quantity}. Only ${cartItem[0].stock} available in stock`);
        error.status = 400;
        throw error;
    }

    await pool.query(
        'UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?',
        [quantity, req.user.id, req.params.productId]
    );

    const [updated] = await pool.query(`
        SELECT
            ci.id AS cart_item_id,
            ci.quantity,
            p.id AS product_id,
            p.name AS product_name,
            p.price,
            p.image_url,
            (p.price * ci.quantity) AS subtotal
        FROM cart_items ci
        INNER JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ? AND ci.product_id = ?
    `, [req.user.id, req.params.productId]);

    res.json({ success: true, data: updated[0], message: 'Cart item updated' });
}));

app.delete('/api/cart/:productId', authMiddleware, asyncHandler(async (req, res) => {
    const [result] = await pool.query(
        'DELETE FROM cart_items WHERE user_id = ? AND product_id = ?',
        [req.user.id, req.params.productId]
    );

    if (result.affectedRows === 0) {
        const error = new Error('Cart item not found');
        error.status = 404;
        throw error;
    }

    res.json({ success: true, message: 'Item removed from cart' });
}));

app.delete('/api/cart', authMiddleware, asyncHandler(async (req, res) => {
    await pool.query('DELETE FROM cart_items WHERE user_id = ?', [req.user.id]);
    res.json({ success: true, message: 'Cart cleared' });
}));

app.post('/api/orders', authMiddleware, asyncHandler(async (req, res) => {
    const { customer_name, customer_email, shipping_address, notes } = req.body;

    if (!customer_name) {
        const error = new Error('Customer name is required');
        error.status = 400;
        throw error;
    }

    const [cartItems] = await pool.query(`
        SELECT ci.product_id, p.name, p.price, ci.quantity, p.stock
        FROM cart_items ci
        INNER JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ? AND p.is_active = TRUE
    `, [req.user.id]);

    if (cartItems.length === 0) {
        const error = new Error('Cart is empty');
        error.status = 400;
        throw error;
    }

    for (const item of cartItems) {
        if (item.quantity > item.stock) {
            const error = new Error(`Insufficient stock for ${item.name}. Only ${item.stock} available`);
            error.status = 400;
            throw error;
        }
    }

    const totalAmount = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();

        const [orderResult] = await connection.query(
            'INSERT INTO orders (user_id, total_amount, customer_name, customer_email, shipping_address, notes) VALUES (?, ?, ?, ?, ?, ?)',
            [req.user.id, totalAmount, customer_name, customer_email || null, shipping_address || null, notes || null]
        );
        const orderId = orderResult.insertId;

        for (const item of cartItems) {
            const subtotal = item.price * item.quantity;
            await connection.query(
                'INSERT INTO order_items (order_id, product_id, product_name, price_at_purchase, quantity, subtotal) VALUES (?, ?, ?, ?, ?, ?)',
                [orderId, item.product_id, item.name, item.price, item.quantity, subtotal]
            );
            await connection.query('UPDATE products SET stock = stock - ? WHERE id = ?', [item.quantity, item.product_id]);
        }

        await connection.query('DELETE FROM cart_items WHERE user_id = ?', [req.user.id]);
        await connection.commit();

        const [newOrder] = await connection.query(`
            SELECT o.*, 
                JSON_ARRAYAGG(JSON_OBJECT(
                    'product_name', oi.product_name,
                    'price', oi.price_at_purchase,
                    'quantity', oi.quantity,
                    'subtotal', oi.subtotal
                )) AS items
            FROM orders o
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.id = ?
            GROUP BY o.id
        `, [orderId]);

        res.status(201).json({ success: true, data: newOrder[0], message: 'Order placed successfully' });
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}));

app.get('/api/orders', authMiddleware, asyncHandler(async (req, res) => {
    const [orders] = await pool.query(`
        SELECT o.*,
            JSON_ARRAYAGG(
                CASE WHEN oi.id IS NOT NULL THEN JSON_OBJECT(
                    'product_name', oi.product_name,
                    'price', oi.price_at_purchase,
                    'quantity', oi.quantity,
                    'subtotal', oi.subtotal
                ) END
            ) AS items
        FROM orders o
        LEFT JOIN order_items oi ON o.id = oi.order_id
        WHERE o.user_id = ?
        GROUP BY o.id
        ORDER BY o.created_at DESC
    `, [req.user.id]);
    res.json({ success: true, data: orders });
}));

app.get('/api/orders/:id', authMiddleware, asyncHandler(async (req, res) => {
    const [order] = await pool.query(`
        SELECT o.*,
            JSON_ARRAYAGG(
                CASE WHEN oi.id IS NOT NULL THEN JSON_OBJECT(
                    'product_name', oi.product_name,
                    'price', oi.price_at_purchase,
                    'quantity', oi.quantity,
                    'subtotal', oi.subtotal
                ) END
            ) AS items
        FROM orders o
        LEFT JOIN order_items oi ON o.id = oi.order_id
        WHERE o.id = ? AND o.user_id = ?
        GROUP BY o.id
    `, [req.params.id, req.user.id]);

    if (order.length === 0) {
        const error = new Error('Order not found');
        error.status = 404;
        throw error;
    }

    res.json({ success: true, data: order[0] });
}));

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use(errorHandler);

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
    console.log('API Endpoints:');
    console.log('  POST   /api/auth/register');
    console.log('  POST   /api/auth/login');
    console.log('  GET    /api/auth/me');
    console.log('  GET    /api/admin/carts  (admin only)');
    console.log('  GET    /api/products');
    console.log('  POST   /api/products');
    console.log('  GET    /api/products/:id');
    console.log('  PUT    /api/products/:id');
    console.log('  DELETE /api/products/:id');
    console.log('  GET    /api/cart');
    console.log('  POST   /api/cart');
    console.log('  PUT    /api/cart/:productId');
    console.log('  DELETE /api/cart/:productId');
    console.log('  DELETE /api/cart (clear cart)');
    console.log('  GET    /api/orders');
    console.log('  POST   /api/orders');
});
