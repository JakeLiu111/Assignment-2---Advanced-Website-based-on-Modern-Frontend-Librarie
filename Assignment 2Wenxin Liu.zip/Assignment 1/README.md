# Maison — E-Commerce Cart

Lightweight shopping cart app, Node.js + MySQL, single-page experience.

## Quick Start

````bash
npm install
node server.js
# Open http://localhost:3000

## Configuration

Edit the database connection in `server.js`:

```javascript
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'shopping_cart_db'
};
````

Or via environment variables: `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`

Tables and sample data are created automatically on first run.

## Tech Stack

Layer Technology

Frontend HTML5 + CSS3 + Vanilla JS
Backend Node.js + Express |
Database MySQL
Styling Custom CSS with variables

## Structure

├── data/schema.sql # Database schema
├── public/index.html # SPA frontend
├── server.js # API server
└── package.json

## Features

- Product catalog with category filtering, search, and sorting
- Persistent shopping cart stored in database
- Inline checkout with order confirmation
- Toast notifications for user feedback
- Responsive design for mobile and desktop

## Challenges

Single-file frontend required managing shared state between cart and checkout views. The cart sidebar switches client-side and server-side. Order creation uses MySQL transactions to keep `orders` and `order_items` in sync.

管理员：admin@admin.com 密码：password
